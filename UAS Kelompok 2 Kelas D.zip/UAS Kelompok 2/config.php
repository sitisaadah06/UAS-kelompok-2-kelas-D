<?php
  $conn = mysqli_connect("sql107.epizy.com", "epiz_28816345", "gY2WSYNy05HZ", "epiz_28816345_todo_list") or exit("Connection Failed.");
?>